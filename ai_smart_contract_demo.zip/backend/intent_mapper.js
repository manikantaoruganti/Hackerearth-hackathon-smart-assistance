const exampleABI = []; // Replace with actual ABI

const intentDB = {
  "stake_eth": {
    contractAddress: "0xYourStakingContractAddress",
    functionName: "stake",
    abi: exampleABI
  },
  "transfer_nft": {
    contractAddress: "0xYourNFTContractAddress",
    functionName: "safeTransferFrom",
    abi: exampleABI
  }
};

function mapIntentToContract(intentKey, args) {
  const config = intentDB[intentKey];
  if (!config) throw new Error("Intent not supported");
  return { ...config, args };
}

module.exports = { mapIntentToContract };
